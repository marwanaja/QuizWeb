let questions = [
    {
    numb: 1,
    question: "Whos ur mine?",
    answer: "Marwan",
    options: [
      "Spongebob",
      "Franklin",
      "Marwan",
      "Shrek"
    ]
  },
    {
    numb: 2,
    question: "When is Marwan's birthday??",
    answer: "June 19",
    options: [
      "March 11",
      "June 19",
      "December 29",
      "Who care!"
    ]
  },
    {
    numb: 3,
    question: "Wanna be mine!",
    answer: " Ask to marwan",
    options: [
      "I don't think so",
      "Ofc",
      "Wanna be mine?",
      "Ask to marwan"
    ]
  },
    {
    numb: 4,
    question: "What a time at ur crush country?",
    answer: "Night",
    options: [
      "Night",
      "Evening",
      "Morning",
      "Night"
    ]
  },
    {
    numb: 5,
    question: "You know our anniversary",
    answer: "Ask to marwan",
    options: [
      "Idk",
      "Ask to marwan",
      "December",
      "November"
    ]
},
];